export interface Value {
    id: number;
    name: string;
}