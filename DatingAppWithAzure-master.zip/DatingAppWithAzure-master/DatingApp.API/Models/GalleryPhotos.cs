namespace DatingApp.API.Models
{
    public class GalleryPhotos
    {
        public string Small { get; set; }

        public string Medium { get; set; }

        public string Big { get; set; }

    }
}