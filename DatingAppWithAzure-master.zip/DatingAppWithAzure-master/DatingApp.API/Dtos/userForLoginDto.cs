namespace DatingApp.API.Dtos
{
    public class userForLoginDto
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}